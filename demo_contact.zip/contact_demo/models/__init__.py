from . import res_partner
from . import product_template

