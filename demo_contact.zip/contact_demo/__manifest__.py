{
    'name':"contact demo",
    'description': "contact demo",
    'version': "17.0.1.0",
    'application': True,
    'category':"Uncategorized",
    'summary': "contact demo",
    'license':"LGPL-3",
    'author': "safa",
    'sequence':"5",
    'depends': [
        'base',
        'product',
],
'data': [
        'views/res_partner_views.xml',
],
}
