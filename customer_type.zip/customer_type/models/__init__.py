from . import customer_type
from . import res_config_settings
from . import stock_picking