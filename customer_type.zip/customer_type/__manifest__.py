{
    'name':"Customer Type",
    'description': "Customer type",
    'version': "17.0.1.0",
    'application': True,
    'category':"Uncategorized",
    'summary': "customer type",
    'license':"LGPL-3",
    'author': "safa",
    'sequence':"1",
    'depends': [
'base',
'stock'
],
'data': [
    'views/customer_type_views.xml',
    'views/res_config_views.xml',
    'views/stock_picking.xml'

],
}
